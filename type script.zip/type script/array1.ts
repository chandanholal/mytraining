console.log("*************************");
let y1: Array<number> = [2016,2017,2018,2019];
for (let i of y1){
	console.log(i)
}

console.log("*************************");
let y2:Array<number>=[2016,2017,2018,2019];
for(let i in y2){
	console.log(y2[i])
}

console.log("*************************");
let y3:Array<number>=[2016,2017,2018,2019];
y3.forEach(function(yrs,i){
	console.log(yrs);
});