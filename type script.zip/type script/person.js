function greeter(person) {
    return "hello, " + person.firstName + " " + person.lastName;
}
var user = { firstName: "jane", lastName: "user" };
console.log(greeter(user));
