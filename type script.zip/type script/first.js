function greeter(person) {
    return "hello," + person;
}
var user = "chandan";
console.log(greeter(user));
