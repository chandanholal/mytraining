function greeter(person){
	return "hello,"+person;
}
let user="chandan";
console.log(greeter(user));