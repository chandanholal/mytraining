function addNumber(a, b) {
    return a + b;
}
var sum = addNumber("JavaTpoint", 25);
console.log('sum of the number is:' + sum);
