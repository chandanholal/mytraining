var student = /** @class */ (function () {
    function student(firstName, middleInt, lastName) {
        this.firstName = firstName;
        this.middleInt = middleInt;
        this.lastName = lastName;
        this.fullName = firstName + " " + middleInt + " " + lastName;
    }
    return student;
}());
function greeter(person) {
    return "hello, " + person.firstName + " " + person.middleInt + " " + person.lastName;
}
var user = new student("jane", "M.", "User");
console.log(greeter(user));
