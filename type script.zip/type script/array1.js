console.log("*************************");
var y1 = [2016, 2017, 2018, 2019];
for (var _i = 0, y1_1 = y1; _i < y1_1.length; _i++) {
    var i = y1_1[_i];
    console.log(i);
}
console.log("*************************");
var y2 = [2016, 2017, 2018, 2019];
for (var i in y2) {
    console.log(y2[i]);
}
console.log("*************************");
var y3 = [2016, 2017, 2018, 2019];
y3.forEach(function (yrs, i) {
    console.log(yrs);
});
