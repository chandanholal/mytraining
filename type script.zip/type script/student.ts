class student{
    fullName: string;
    constructor(public firstName: string, public middleInt:string, public lastName:string){
        this.fullName=firstName+" "+middleInt+" "+lastName;
    }
}

interface Person{
    firstName: string;
    middleInt: string
    lastName: string;
}

function greeter(person:Person){
    return "hello, " + person.firstName+" "+person.middleInt+" "+person.lastName;
}

let user = new student("jane","M.","User");

console.log(greeter(user));