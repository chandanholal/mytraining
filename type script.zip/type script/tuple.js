var empTuple = ["rohit", 25, "java"];
console.log("Items :" + empTuple);
console.log("Lenght of Tuple Item before push:" + empTuple.length);
empTuple.push(1001);
console.log("Length of tuple after push:" + empTuple.length);
console.log("Items :" + empTuple);
